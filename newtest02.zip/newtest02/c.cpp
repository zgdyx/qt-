﻿#include "c.h"
#include "ui_c.h"
#include<QDebug>
#include<QFile>
#include<QTableWidget>
#include<QTextStream>
#include <QApplication>
#include <QTableWidget>






c::c(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::c)
{
    ui->setupUi(this);

    m_countNum=0;

    QStringList headlist;
    headlist <<"物品名"<<"拾取地点"<<"领取处"<<"认领状况"<<"申请人"<<"学号";

    ui->tableWidget->setColumnCount(headlist.size());
    ui->tableWidget->setHorizontalHeaderLabels(headlist);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    QString strFilepath = "D:\\BaiduNetdiskDownload\\test.txt";

    QFile file(strFilepath);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        int row = 0;
        while (!in.atEnd()) {

            QString line = in.readLine();
            QStringList items = line.split("*");
            if (items.size() == headlist.size()) {
                ui->tableWidget->insertRow(row);
                for (int i = 0; i < items.size(); i++) {

                    QTableWidgetItem *item = new QTableWidgetItem(items[i]);
                    ui->tableWidget->setItem(row, i, item);
                }
                row++;
            }
        }
        file.close();
        QString st = QString("读取成功");
        ui->textEdit->append(st);
    } else {
        file.close();
        QString st1 = QString("读取失败");
        ui->textEdit->append(st1);
    }




}


c::~c()
{
    delete ui;
}





void c::on_pushButton_clicked()
{
    int rowcount=ui->tableWidget->rowCount();
    m_countNum++;
    QString strCont =QString::number(m_countNum);
    int curRow=ui->tableWidget->currentRow();
    qDebug()<<curRow;
    int newRow=curRow+1;
    ui->tableWidget->insertRow(newRow);
    QTableWidgetItem *it[6];
    it[3]=new QTableWidgetItem("暂无");
    it[4]=new QTableWidgetItem("/");
    it[5]=new QTableWidgetItem("/");
    ui->tableWidget->setItem(newRow,3,it[3]);
    ui->tableWidget->setItem(newRow,4,it[4]);
    ui->tableWidget->setItem(newRow,5,it[5]);





}


void c::on_pushButton_2_clicked()
{
    if(ui->lineEdit->text()=="123"){
        int currow=ui->tableWidget->currentRow();
        QString strMsg;
        if(-1==currow){
            strMsg=QString("未选中要删除的行");
        }else{

        }
        ui->textEdit->append(strMsg);
        ui->tableWidget->removeRow(currow);
    }
    else{
        ui->lineEdit->setText("管理员码错误");
    }

}


void c::on_pushButton_3_clicked()
{


    QTableWidgetItem *cell1;


    QString strFilepath="D:\\BaiduNetdiskDownload\\test.txt";
    QFile file(strFilepath);

    if(file.open(QIODevice::WriteOnly | QIODevice::Text)){

         QTextStream out(&file);

         for(int i=0;i<ui->tableWidget->rowCount();i++){
            for(int j=0;j<ui->tableWidget->columnCount();j++){
                 cell1=ui->tableWidget->item(i,j);
                out<<cell1->text();
                 if(j!=ui->tableWidget->columnCount()-1){
                    out<<'*';
                }
             }
            out<<'\n';

        }


        file.close();
        QString st;
        st=QString("保存成功");
        ui->textEdit->append(st);




    }
    else{
        file.close();
        QString st1;
        st1=QString("保存失败");
        ui->textEdit->append(st1);

    }




}

void c::on_pushButton_4_clicked()
{
    deleteLater();



}

