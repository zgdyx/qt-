﻿#ifndef C_H
#define C_H

#include <QDialog>
#include<QUrl>
#include<QDesktopServices>
#include<QFile>
#include<QTableWidget>
#include<QTextStream>
#include <QApplication>



namespace Ui {
class c;
}

class c : public QDialog
{
    Q_OBJECT

public:
    explicit c(QWidget *parent = nullptr);
    ~c();

private:
    void importDataFromTxtToTableWidget(const QString &fileName, QTableWidget *tableWidget);



private slots:
    void on_pushButton_clicked();




    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::c *ui;
    int m_countNum;
};


#endif // C_H
