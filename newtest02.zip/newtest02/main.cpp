﻿#include "mine1dialog.h"

#include <QApplication>
#include<QFile>

int main(int argc, char *argv[])
{

    QApplication a(argc, argv);
    mine1Dialog w;
    w.resize(800,600);
    w.show();
    return a.exec();


}
