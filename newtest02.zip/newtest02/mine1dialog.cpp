﻿#include "mine1dialog.h"
#include "ui_mine1dialog.h"

mine1Dialog::mine1Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::mine1Dialog)
{
    ui->setupUi(this);



}

mine1Dialog::~mine1Dialog()
{
    delete ui;
}

void mine1Dialog::on_pushButton_clicked()
{


    a *s=new a;
    s->show();




}


void mine1Dialog::on_pushButton_2_clicked()
{
    b *w=new b;
    w->show();
}



