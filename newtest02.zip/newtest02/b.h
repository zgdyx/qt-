﻿#ifndef B_H
#define B_H

#include <QDialog>

namespace Ui {
class b;
}

class b : public QDialog
{
    Q_OBJECT

public:
    explicit b(QWidget *parent = nullptr);
    ~b();

private slots:
    void on_pushButton_clicked();

private:
    Ui::b *ui;
};

#endif // B_H
