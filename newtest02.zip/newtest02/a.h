#ifndef A_H
#define A_H

#include <QDialog>

namespace Ui {
class a;
}

class a : public QDialog
{
    Q_OBJECT









public:
    explicit a(QWidget *parent = nullptr);
    ~a();

private slots:
    void on_pushButton_clicked();



private:
    Ui::a *ui;
};

#endif // A_H
