﻿#include "b.h"
#include "ui_b.h"

b::b(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::b)
{
    ui->setupUi(this);
}

b::~b()
{
    delete ui;
}

void b::on_pushButton_clicked()
{
    deleteLater();

}

