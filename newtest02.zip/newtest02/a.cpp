﻿
#include "a.h"
#include "ui_a.h"
#include "c.h"

a::a(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::a)
{
    ui->setupUi(this);


}

a::~a()
{
    delete ui;
}

void a::on_pushButton_clicked()
{
    if(ui->lineEdit->text()=="zhangsan"&&ui->lineEdit_2->text()=="666"){
        accept();
        c *f=new c;
        f->show();

    }
    else{
        ui->label_3->setText("用户名或密码错误");

        ui->lineEdit->clear();

        ui->lineEdit_2->clear();

        ui->lineEdit->setFocus();
    }
}

