﻿#ifndef MINE1DIALOG_H
#define MINE1DIALOG_H

#include <QDialog>
#include<a.h>
#include<b.h>

QT_BEGIN_NAMESPACE
namespace Ui {
class mine1Dialog;
}
QT_END_NAMESPACE

class mine1Dialog : public QDialog
{
    Q_OBJECT

public:
    mine1Dialog(QWidget *parent = nullptr);
    ~mine1Dialog();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::mine1Dialog *ui;
};
#endif // MINE1DIALOG_H
